import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Settings, Save } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { toast } from 'sonner@2.0.3';
import { User } from '../../App';

interface CodeConfigurationProps {
  user: User;
}

interface CodeConfig {
  couponPrefix: string;
  couponSuffix: string;
  qrCodeFormat: string;
  barCodeLength: number;
}

export default function CodeConfiguration({ user }: CodeConfigurationProps) {
  const [config, setConfig] = useState<CodeConfig>({
    couponPrefix: 'R',
    couponSuffix: 'S',
    qrCodeFormat: '{PRODUCT_ID}-{MMYY}-{COUPON_CODE}-{PLANT_CODE}',
    barCodeLength: 12,
  });

  useEffect(() => {
    const savedConfig = localStorage.getItem('code_config');
    if (savedConfig) {
      setConfig(JSON.parse(savedConfig));
    }
  }, []);

  const handleSave = () => {
    localStorage.setItem('code_config', JSON.stringify(config));
    toast.success('Code generation configuration saved successfully');
  };

  return (
    <div className="max-w-4xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="mb-6">
          <h1 className="mb-2">Code Generation Configuration</h1>
          <p className="text-body">Configure coupon, QR code, and barcode generation settings</p>
        </div>

        {/* Coupon Code Configuration */}
        <motion.div
          className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card mb-6"
          whileTap={{ scale: 0.98 }}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-[#091A7A] flex items-center justify-center">
              <Settings className="w-5 h-5 text-white" />
            </div>
            <h2>Coupon Code Settings</h2>
          </div>

          <div className="space-y-4">
            <div className="bg-[#ADC8FF]/20 p-4 rounded-[var(--radius-small)] border border-[#ADC8FF]/40 mb-4">
              <p className="text-body text-[#091A7A] mb-2">
                <strong>Format:</strong> {'{MONTH}'}{config.couponPrefix}{'XXXXXXXX'}{config.couponSuffix}
              </p>
              <p className="text-small text-[#6B7280]">
                Example: 02{config.couponPrefix}LI2CIAAS{config.couponSuffix} (February generation)
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="prefix">Coupon Prefix</Label>
                <Input
                  id="prefix"
                  value={config.couponPrefix}
                  onChange={(e) => setConfig({ ...config, couponPrefix: e.target.value })}
                  placeholder="e.g., R"
                  className="mt-2 bg-white/70 backdrop-blur-sm border-white/30"
                  maxLength={5}
                />
                <p className="text-tiny text-[#6B7280] mt-1">Single character or short prefix</p>
              </div>

              <div>
                <Label htmlFor="suffix">Coupon Suffix</Label>
                <Input
                  id="suffix"
                  value={config.couponSuffix}
                  onChange={(e) => setConfig({ ...config, couponSuffix: e.target.value })}
                  placeholder="e.g., S"
                  className="mt-2 bg-white/70 backdrop-blur-sm border-white/30"
                  maxLength={5}
                />
                <p className="text-tiny text-[#6B7280] mt-1">Single character or short suffix</p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* QR Code Configuration */}
        <motion.div
          className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card mb-6"
          whileTap={{ scale: 0.98 }}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-[#091A7A] flex items-center justify-center">
              <Settings className="w-5 h-5 text-white" />
            </div>
            <h2>QR Code Settings</h2>
          </div>

          <div className="space-y-4">
            <div className="bg-[#ADC8FF]/20 p-4 rounded-[var(--radius-small)] border border-[#ADC8FF]/40 mb-4">
              <p className="text-body text-[#091A7A] mb-2">
                <strong>Format:</strong> {config.qrCodeFormat}
              </p>
              <p className="text-small text-[#6B7280]">
                Example: P001-0225-02RLI2CIAASS-MUM001
              </p>
            </div>

            <div>
              <Label htmlFor="qrFormat">QR Code Format</Label>
              <Input
                id="qrFormat"
                value={config.qrCodeFormat}
                onChange={(e) => setConfig({ ...config, qrCodeFormat: e.target.value })}
                className="mt-2 bg-white/70 backdrop-blur-sm border-white/30"
                disabled
              />
              <p className="text-tiny text-[#6B7280] mt-1">
                Variables: {'{PRODUCT_ID}'}, {'{MMYY}'}, {'{COUPON_CODE}'}, {'{PLANT_CODE}'}
              </p>
            </div>
          </div>
        </motion.div>

        {/* Bar Code Configuration */}
        <motion.div
          className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card mb-6"
          whileTap={{ scale: 0.98 }}
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-[#091A7A] flex items-center justify-center">
              <Settings className="w-5 h-5 text-white" />
            </div>
            <h2>Bar Code Settings</h2>
          </div>

          <div className="space-y-4">
            <div className="bg-[#ADC8FF]/20 p-4 rounded-[var(--radius-small)] border border-[#ADC8FF]/40 mb-4">
              <p className="text-body text-[#091A7A] mb-2">
                <strong>Format:</strong> {'{2-DIGIT RANDOM}'}{'{MONTH}'}{'{SEQUENCE}'}
              </p>
              <p className="text-small text-[#6B7280]">
                Example: 420210000496 (42 = random, 02 = February, 10000496 = sequence)
              </p>
            </div>

            <div>
              <Label htmlFor="barLength">Bar Code Length</Label>
              <Input
                id="barLength"
                type="number"
                value={config.barCodeLength}
                onChange={(e) => setConfig({ ...config, barCodeLength: parseInt(e.target.value) })}
                className="mt-2 bg-white/70 backdrop-blur-sm border-white/30"
                disabled
              />
              <p className="text-tiny text-[#6B7280] mt-1">Standard 12-digit format</p>
            </div>
          </div>
        </motion.div>

        {/* Code Generation Examples */}
        <motion.div
          className="bg-[#10B981]/10 border border-[#10B981]/30 rounded-[var(--radius-standard)] p-6 mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <h3 className="text-[#091A7A] mb-3">Generated Code Examples (February 2026)</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between bg-white/50 p-3 rounded-[var(--radius-small)]">
              <span className="text-body text-[#6B7280]">Coupon Code:</span>
              <span className="text-body font-medium text-[#091A7A]">02{config.couponPrefix}LI2CIAAS{config.couponSuffix}</span>
            </div>
            <div className="flex items-center justify-between bg-white/50 p-3 rounded-[var(--radius-small)]">
              <span className="text-body text-[#6B7280]">QR Code:</span>
              <span className="text-body font-medium text-[#091A7A]">P001-0226-02{config.couponPrefix}LI2CIAAS{config.couponSuffix}-MUM001</span>
            </div>
            <div className="flex items-center justify-between bg-white/50 p-3 rounded-[var(--radius-small)]">
              <span className="text-body text-[#6B7280]">Bar Code:</span>
              <span className="text-body font-medium text-[#091A7A]">420210000496</span>
            </div>
          </div>
        </motion.div>

        {/* Save Button */}
        <motion.div whileTap={{ scale: 0.95 }}>
          <Button
            onClick={handleSave}
            className="w-full h-14 bg-[#091A7A] text-white rounded-[var(--radius-standard)] shadow-interactive"
          >
            <Save className="w-5 h-5 mr-2" />
            Save Configuration
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
}
