import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Link2, Search } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { toast } from 'sonner@2.0.3';
import { User } from '../../App';

interface BatchMappingsProps {
  user: User;
}

interface BatchInfo {
  id: string;
  name: string;
  size: number;
}

const mockBatches: Record<string, BatchInfo> = {
  '1037': { id: '1037', name: 'Coupon-M', size: 50 },
  '1036': { id: '1036', name: 'valid_C', size: 100 },
  '1038': { id: '1038', name: 'Master-Carton-Batch', size: 25 },
  '1039': { id: '1039', name: 'Unit-Product-Batch', size: 500 },
};

export default function BatchMappings({ user }: BatchMappingsProps) {
  const [parentBatchId, setParentBatchId] = useState('');
  const [childBatchId, setChildBatchId] = useState('');
  const [cartSize, setCartSize] = useState('');
  
  const [parentBatch, setParentBatch] = useState<BatchInfo | null>(null);
  const [childBatch, setChildBatch] = useState<BatchInfo | null>(null);

  const handleSearchParent = () => {
    const batch = mockBatches[parentBatchId];
    if (batch) {
      setParentBatch(batch);
      toast.success('Parent batch found');
    } else {
      setParentBatch(null);
      toast.error('Parent batch not found');
    }
  };

  const handleSearchChild = () => {
    const batch = mockBatches[childBatchId];
    if (batch) {
      setChildBatch(batch);
      toast.success('Child batch found');
    } else {
      setChildBatch(null);
      toast.error('Child batch not found');
    }
  };

  const handleMap = () => {
    if (!parentBatch || !childBatch || !cartSize || parseInt(cartSize) <= 0) {
      toast.error('Please fill all fields and search for both batches');
      return;
    }

    const cart = parseInt(cartSize);
    const totalChildrenNeeded = parentBatch.size * cart;

    if (totalChildrenNeeded > childBatch.size) {
      toast.error(
        `Insufficient child coupons. Need ${totalChildrenNeeded} but only ${childBatch.size} available.`
      );
      return;
    }

    toast.success(
      `Successfully mapped ${cart} child coupons to each of ${parentBatch.size} parent coupons`,
      { duration: 5000 }
    );

    // Reset form
    setParentBatchId('');
    setChildBatchId('');
    setCartSize('');
    setParentBatch(null);
    setChildBatch(null);
  };

  return (
    <div className="max-w-4xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="mb-6">
          <h1 className="mb-2">Coupon Batch Mappings</h1>
          <p className="text-body">Create parent-child relationships between coupon batches</p>
        </div>

        {/* Info Box */}
        <motion.div
          className="bg-[#ADC8FF]/20 border border-[#ADC8FF]/40 rounded-[var(--radius-standard)] p-6 mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="text-[#091A7A] mb-2">About Batch Mappings</h3>
          <p className="text-body text-[#6B7280] mb-3">
            Batch mappings define a parent-child relationship between two distinct coupon batches. 
            This feature is useful for tracking products as they move through a distribution channel.
          </p>
          <p className="text-body text-[#6B7280]">
            <strong>Example:</strong> A coupon for a master carton (parent) can be linked to coupons 
            for individual product units (children) inside it. If a master carton holds 20 SKUs, 
            set the cart size to 20.
          </p>
        </motion.div>

        {/* Map Coupons Form */}
        <motion.div
          className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
          whileTap={{ scale: 0.98 }}
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-full bg-[#091A7A] flex items-center justify-center">
              <Link2 className="w-5 h-5 text-white" />
            </div>
            <h2>Map Coupons</h2>
          </div>

          <div className="space-y-6">
            {/* Parent Batch */}
            <div className="space-y-4">
              <h3 className="text-[#091A7A]">Parent Batch</h3>
              
              <div>
                <Label htmlFor="parentBatchId">Parent Batch ID *</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    id="parentBatchId"
                    value={parentBatchId}
                    onChange={(e) => setParentBatchId(e.target.value)}
                    placeholder="Enter parent batch ID (e.g., 1037)"
                    className="bg-white/70 backdrop-blur-sm border-white/30"
                  />
                  <motion.div whileTap={{ scale: 0.95 }}>
                    <Button
                      onClick={handleSearchParent}
                      variant="outline"
                      className="border-[#091A7A] text-[#091A7A]"
                    >
                      <Search className="w-5 h-5" />
                    </Button>
                  </motion.div>
                </div>
              </div>

              {parentBatch && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="grid grid-cols-2 gap-4"
                >
                  <div className="bg-white/70 backdrop-blur-sm border border-white/30 rounded-[var(--radius-small)] p-4">
                    <p className="text-tiny text-[#9CA3AF] mb-1">Parent Batch Name</p>
                    <p className="text-body font-medium text-[#091A7A]">{parentBatch.name}</p>
                  </div>
                  <div className="bg-white/70 backdrop-blur-sm border border-white/30 rounded-[var(--radius-small)] p-4">
                    <p className="text-tiny text-[#9CA3AF] mb-1">Parent Batch Size</p>
                    <p className="text-body font-medium text-[#091A7A]">{parentBatch.size} coupons</p>
                  </div>
                </motion.div>
              )}
            </div>

            {/* Child Batch */}
            <div className="space-y-4 pt-4 border-t border-white/20">
              <h3 className="text-[#091A7A]">Child Batch</h3>
              
              <div>
                <Label htmlFor="childBatchId">Child Batch ID *</Label>
                <div className="flex gap-2 mt-2">
                  <Input
                    id="childBatchId"
                    value={childBatchId}
                    onChange={(e) => setChildBatchId(e.target.value)}
                    placeholder="Enter child batch ID (e.g., 1036)"
                    className="bg-white/70 backdrop-blur-sm border-white/30"
                  />
                  <motion.div whileTap={{ scale: 0.95 }}>
                    <Button
                      onClick={handleSearchChild}
                      variant="outline"
                      className="border-[#091A7A] text-[#091A7A]"
                    >
                      <Search className="w-5 h-5" />
                    </Button>
                  </motion.div>
                </div>
              </div>

              {childBatch && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="grid grid-cols-2 gap-4"
                >
                  <div className="bg-white/70 backdrop-blur-sm border border-white/30 rounded-[var(--radius-small)] p-4">
                    <p className="text-tiny text-[#9CA3AF] mb-1">Child Batch Name</p>
                    <p className="text-body font-medium text-[#091A7A]">{childBatch.name}</p>
                  </div>
                  <div className="bg-white/70 backdrop-blur-sm border border-white/30 rounded-[var(--radius-small)] p-4">
                    <p className="text-tiny text-[#9CA3AF] mb-1">Child Batch Size</p>
                    <p className="text-body font-medium text-[#091A7A]">{childBatch.size} coupons</p>
                  </div>
                </motion.div>
              )}
            </div>

            {/* Cart Size */}
            <div className="pt-4 border-t border-white/20">
              <Label htmlFor="cartSize">Cart Size *</Label>
              <Input
                id="cartSize"
                type="number"
                min="1"
                value={cartSize}
                onChange={(e) => setCartSize(e.target.value)}
                placeholder="Number of child coupons per parent (e.g., 20)"
                className="mt-2 bg-white/70 backdrop-blur-sm border-white/30"
              />
              <p className="text-tiny text-[#6B7280] mt-2">
                Based on the capacity of the master carton. If a master carton holds 20 SKUs, enter 20.
              </p>
            </div>

            {/* Calculation Preview */}
            {parentBatch && childBatch && cartSize && parseInt(cartSize) > 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-[#10B981]/10 border border-[#10B981]/30 rounded-[var(--radius-small)] p-4"
              >
                <p className="text-body text-[#091A7A] mb-2">
                  <strong>Mapping Preview:</strong>
                </p>
                <ul className="space-y-1 text-body text-[#6B7280]">
                  <li>• {parentBatch.size} parent coupons × {cartSize} child coupons = {parentBatch.size * parseInt(cartSize)} child coupons needed</li>
                  <li>• Available child coupons: {childBatch.size}</li>
                  <li className={parentBatch.size * parseInt(cartSize) <= childBatch.size ? 'text-[#10B981]' : 'text-[#EF4444]'}>
                    • Status: {parentBatch.size * parseInt(cartSize) <= childBatch.size ? '✓ Sufficient' : '✗ Insufficient'}
                  </li>
                </ul>
              </motion.div>
            )}

            {/* Map Button */}
            <motion.div whileTap={{ scale: 0.95 }} className="pt-4">
              <Button
                onClick={handleMap}
                className="w-full h-14 bg-[#091A7A] text-white rounded-[var(--radius-standard)] shadow-interactive"
              >
                <Link2 className="w-5 h-5 mr-2" />
                Map Coupons
              </Button>
            </motion.div>
          </div>
        </motion.div>

        {/* Example Batches Reference */}
        <motion.div
          className="mt-6 bg-white/70 backdrop-blur-sm border border-white/30 rounded-[var(--radius-standard)] p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <p className="text-body text-[#091A7A] mb-3">
            <strong>Available Test Batches:</strong>
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-tiny text-[#6B7280]">
            {Object.values(mockBatches).map((batch) => (
              <div key={batch.id} className="bg-white/50 p-2 rounded">
                ID: {batch.id} - {batch.name} ({batch.size} coupons)
              </div>
            ))}
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
