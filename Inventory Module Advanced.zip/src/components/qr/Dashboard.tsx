import React from 'react';
import { motion } from 'motion/react';
import { QrCode, Factory, Package, FileCheck, Printer, TrendingUp, Clock, CheckCircle2 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { User } from '../../App';

interface DashboardProps {
  user: User;
}

// Mock data for charts
const plantData = [
  { name: 'Mumbai', count: 15420 },
  { name: 'Delhi', count: 12890 },
  { name: 'Bangalore', count: 11230 },
  { name: 'Chennai', count: 9870 },
];

const productData = [
  { name: 'Premium Tea', value: 18500 },
  { name: 'Classic Coffee', value: 15200 },
  { name: 'Green Tea', value: 12800 },
  { name: 'Masala Chai', value: 8900 },
  { name: 'Others', value: 6100 },
];

const COLORS = ['#091A7A', '#ADC8FF', '#10B981', '#F59E0B', '#EF4444'];

export default function Dashboard({ user }: DashboardProps) {
  const stats = {
    totalQRGenerated: 61500,
    pendingRequests: 3,
    activePlants: 4,
    activeProducts: 12,
    printQueue: 2,
    monthlyGrowth: 23.5,
  };

  const recentActivity = [
    { action: 'QR Batch Generated', details: '1000 codes for Premium Tea 500g', time: '2 hours ago', type: 'success' },
    { action: 'Request Approved', details: 'Mumbai Plant - Batch BATCH-2026-005', time: '4 hours ago', type: 'info' },
    { action: 'Print Job Completed', details: '500 QR codes printed', time: '6 hours ago', type: 'success' },
    { action: 'New Request Created', details: 'Delhi Plant - 2000 codes requested', time: '1 day ago', type: 'warning' },
  ];

  return (
    <div className="max-w-7xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        {/* Header */}
        <div className="mb-6">
          <h1 className="mb-2">Dashboard</h1>
          <p className="text-body">Welcome back, {user.name}</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
            whileTap={{ scale: 0.98 }}
            className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 rounded-full bg-[#091A7A] flex items-center justify-center">
                <QrCode className="w-6 h-6 text-white" />
              </div>
              <div className="flex items-center gap-1 text-[#10B981]">
                <TrendingUp className="w-4 h-4" />
                <span className="text-tiny">+{stats.monthlyGrowth}%</span>
              </div>
            </div>
            <h3 className="text-[#091A7A] mb-1">{stats.totalQRGenerated.toLocaleString()}</h3>
            <p className="text-body">Total QR Codes Generated</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            whileTap={{ scale: 0.98 }}
            className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 rounded-full bg-[#F59E0B] flex items-center justify-center">
                <Clock className="w-6 h-6 text-white" />
              </div>
            </div>
            <h3 className="text-[#091A7A] mb-1">{stats.pendingRequests}</h3>
            <p className="text-body">Pending Requests</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            whileTap={{ scale: 0.98 }}
            className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 rounded-full bg-[#10B981] flex items-center justify-center">
                <Factory className="w-6 h-6 text-white" />
              </div>
            </div>
            <h3 className="text-[#091A7A] mb-1">{stats.activePlants}</h3>
            <p className="text-body">Active Plants</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
            whileTap={{ scale: 0.98 }}
            className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 rounded-full bg-[#ADC8FF] flex items-center justify-center">
                <Package className="w-6 h-6 text-[#091A7A]" />
              </div>
            </div>
            <h3 className="text-[#091A7A] mb-1">{stats.activeProducts}</h3>
            <p className="text-body">Active Products</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5 }}
            whileTap={{ scale: 0.98 }}
            className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 rounded-full bg-[#091A7A] flex items-center justify-center">
                <Printer className="w-6 h-6 text-white" />
              </div>
            </div>
            <h3 className="text-[#091A7A] mb-1">{stats.printQueue}</h3>
            <p className="text-body">Print Queue</p>
          </motion.div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
          >
            <h2 className="mb-4">Plant-wise QR Distribution</h2>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={plantData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(9, 26, 122, 0.1)" />
                  <XAxis 
                    dataKey="name" 
                    tick={{ fill: '#6B7280', fontSize: 12 }}
                  />
                  <YAxis 
                    tick={{ fill: '#6B7280', fontSize: 12 }}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.95)',
                      border: '1px solid rgba(173, 200, 255, 0.3)',
                      borderRadius: '12px',
                      boxShadow: '0 4px 20px rgba(9, 26, 122, 0.15)'
                    }}
                  />
                  <Bar dataKey="count" fill="#091A7A" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
          >
            <h2 className="mb-4">Top Products by QR Codes</h2>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={productData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={(entry) => entry.name}
                    outerRadius={90}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {productData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.95)',
                      border: '1px solid rgba(173, 200, 255, 0.3)',
                      borderRadius: '12px',
                      boxShadow: '0 4px 20px rgba(9, 26, 122, 0.15)'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        </div>

        {/* Recent Activity */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
        >
          <h2 className="mb-4">Recent Activity</h2>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-start gap-4 pb-4 border-b border-white/20 last:border-b-0">
                <div className={`w-2 h-2 mt-2 rounded-full ${
                  activity.type === 'success' ? 'bg-[#10B981]' :
                  activity.type === 'warning' ? 'bg-[#F59E0B]' :
                  'bg-[#091A7A]'
                }`} />
                <div className="flex-1">
                  <p className="text-body font-medium text-[#091A7A]">{activity.action}</p>
                  <p className="text-small text-[#6B7280]">{activity.details}</p>
                </div>
                <p className="text-tiny text-[#9CA3AF]">{activity.time}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
