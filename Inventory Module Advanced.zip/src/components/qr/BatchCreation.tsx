import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Package, Factory, Hash, FileText, Plus, Send, X } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { toast } from 'sonner@2.0.3';
import { User } from '../../App';

interface BatchCreationProps {
  user: User;
}

const mockPlants = [
  { id: '1', name: 'Mumbai Plant', code: 'MUM-01' },
  { id: '2', name: 'Delhi Plant', code: 'DEL-01' },
  { id: '3', name: 'Bangalore Plant', code: 'BLR-01' },
  { id: '4', name: 'Chennai Plant', code: 'CHN-01' },
];

const mockProducts = [
  { id: '1', name: 'Premium Tea 500g', sku: 'TEA-500-P', externalId: 'P001', mrp: 450 },
  { id: '2', name: 'Classic Coffee 250g', sku: 'COF-250-C', externalId: 'P002', mrp: 320 },
  { id: '3', name: 'Green Tea 100g', sku: 'TEA-100-G', externalId: 'P003', mrp: 180 },
  { id: '4', name: 'Masala Chai 1kg', sku: 'TEA-1000-M', externalId: 'P004', mrp: 650 },
];

interface ProductSelection {
  productId: string;
  quantity: number;
}

export default function BatchCreation({ user }: BatchCreationProps) {
  const [formData, setFormData] = useState({
    batchName: '',
    plantId: '',
    totalCoupons: '',
    referenceId: '',
    remarks: '',
  });

  const [selectedProducts, setSelectedProducts] = useState<ProductSelection[]>([]);
  const [currentProduct, setCurrentProduct] = useState('');
  const [currentQuantity, setCurrentQuantity] = useState('');

  const handleAddProduct = () => {
    if (!currentProduct || !currentQuantity || parseInt(currentQuantity) <= 0) {
      toast.error('Please select a product and enter valid quantity');
      return;
    }

    const product = mockProducts.find(p => p.id === currentProduct);
    if (!product) return;

    // Check if product already added
    const existingIndex = selectedProducts.findIndex(p => p.productId === currentProduct);
    if (existingIndex >= 0) {
      toast.error('Product already added. Remove it first to update quantity.');
      return;
    }

    setSelectedProducts([
      ...selectedProducts,
      { productId: currentProduct, quantity: parseInt(currentQuantity) }
    ]);

    setCurrentProduct('');
    setCurrentQuantity('');
    toast.success('Product added to batch');
  };

  const handleRemoveProduct = (productId: string) => {
    setSelectedProducts(selectedProducts.filter(p => p.productId !== productId));
    toast.info('Product removed from batch');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.batchName || !formData.plantId || !formData.totalCoupons) {
      toast.error('Please fill all required fields');
      return;
    }

    if (selectedProducts.length === 0) {
      toast.error('Please add at least one product to the batch');
      return;
    }

    // Mock batch creation
    const batchId = `BATCH-${Date.now()}`;
    
    toast.success(
      `Batch created successfully! Batch ID: ${batchId}. Coupon generation is in progress.`,
      { duration: 5000 }
    );

    // Reset form
    setFormData({
      batchName: '',
      plantId: '',
      totalCoupons: '',
      referenceId: '',
      remarks: '',
    });
    setSelectedProducts([]);
  };

  const getProductDetails = (productId: string) => {
    return mockProducts.find(p => p.id === productId);
  };

  const totalQuantity = selectedProducts.reduce((sum, p) => sum + p.quantity, 0);

  return (
    <div className="max-w-4xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="mb-6">
          <h1 className="mb-2">Create Batch</h1>
          <p className="text-body">Create a new coupon batch with multiple products</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Batch Configuration */}
          <motion.div
            className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
            whileTap={{ scale: 0.98 }}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-[#091A7A] flex items-center justify-center">
                <Factory className="w-5 h-5 text-white" />
              </div>
              <h2>Batch Configuration</h2>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="batchName">Batch Name *</Label>
                <Input
                  id="batchName"
                  value={formData.batchName}
                  onChange={(e) => setFormData({ ...formData, batchName: e.target.value })}
                  placeholder="e.g., TEA-BATCH-FEB-2026"
                  className="mt-2 bg-white/70 backdrop-blur-sm border-white/30"
                  required
                />
              </div>

              <div>
                <Label htmlFor="plant">Manufacturing Plant *</Label>
                <select
                  id="plant"
                  value={formData.plantId}
                  onChange={(e) => setFormData({ ...formData, plantId: e.target.value })}
                  className="w-full mt-2 px-4 py-3 bg-white/70 backdrop-blur-sm border border-white/30 rounded-[var(--radius-small)] outline-none focus:border-[#091A7A] transition-colors"
                  required
                >
                  <option value="">Choose a plant...</option>
                  {mockPlants.map(plant => (
                    <option key={plant.id} value={plant.id}>
                      {plant.name} ({plant.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label htmlFor="totalCoupons">Number of Coupons *</Label>
                <Input
                  id="totalCoupons"
                  type="number"
                  min="1"
                  value={formData.totalCoupons}
                  onChange={(e) => setFormData({ ...formData, totalCoupons: e.target.value })}
                  placeholder="Total quantity of coupons to generate"
                  className="mt-2 bg-white/70 backdrop-blur-sm border-white/30"
                  required
                />
              </div>

              <div>
                <Label htmlFor="referenceId">Reference ID (Optional)</Label>
                <Input
                  id="referenceId"
                  value={formData.referenceId}
                  onChange={(e) => setFormData({ ...formData, referenceId: e.target.value })}
                  placeholder="Internal reference code"
                  className="mt-2 bg-white/70 backdrop-blur-sm border-white/30"
                />
              </div>
            </div>
          </motion.div>

          {/* Product Selection */}
          <motion.div
            className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
            whileTap={{ scale: 0.98 }}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-[#091A7A] flex items-center justify-center">
                <Package className="w-5 h-5 text-white" />
              </div>
              <h2>Product Selection *</h2>
            </div>

            <div className="space-y-4">
              {/* Add Product Form */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="md:col-span-2">
                  <Label htmlFor="product">Select Product</Label>
                  <select
                    id="product"
                    value={currentProduct}
                    onChange={(e) => setCurrentProduct(e.target.value)}
                    className="w-full mt-2 px-4 py-3 bg-white/70 backdrop-blur-sm border border-white/30 rounded-[var(--radius-small)] outline-none focus:border-[#091A7A] transition-colors"
                  >
                    <option value="">Choose a product...</option>
                    {mockProducts.map(product => (
                      <option key={product.id} value={product.id}>
                        {product.name} ({product.externalId}) - ₹{product.mrp}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <Label htmlFor="quantity">Quantity</Label>
                  <div className="flex gap-2 mt-2">
                    <Input
                      id="quantity"
                      type="number"
                      min="1"
                      value={currentQuantity}
                      onChange={(e) => setCurrentQuantity(e.target.value)}
                      placeholder="Qty"
                      className="bg-white/70 backdrop-blur-sm border-white/30"
                    />
                    <motion.div whileTap={{ scale: 0.95 }}>
                      <Button
                        type="button"
                        onClick={handleAddProduct}
                        className="bg-[#10B981] text-white hover:bg-[#10B981]/90"
                      >
                        <Plus className="w-5 h-5" />
                      </Button>
                    </motion.div>
                  </div>
                </div>
              </div>

              {/* Selected Products List */}
              {selectedProducts.length > 0 && (
                <div className="space-y-2">
                  <Label>Selected Products ({selectedProducts.length})</Label>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {selectedProducts.map((selection) => {
                      const product = getProductDetails(selection.productId);
                      if (!product) return null;

                      return (
                        <div
                          key={selection.productId}
                          className="bg-white/70 backdrop-blur-sm border border-white/30 rounded-[var(--radius-small)] p-3 flex items-center justify-between"
                        >
                          <div className="flex-1">
                            <p className="text-body font-medium text-[#091A7A]">{product.name}</p>
                            <p className="text-tiny text-[#6B7280]">
                              {product.externalId} • SKU: {product.sku} • ₹{product.mrp}
                            </p>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="bg-[#091A7A]/10 px-3 py-1 rounded-full">
                              <p className="text-body font-medium text-[#091A7A]">
                                Qty: {selection.quantity.toLocaleString()}
                              </p>
                            </div>
                            <motion.button
                              type="button"
                              whileTap={{ scale: 0.9 }}
                              onClick={() => handleRemoveProduct(selection.productId)}
                              className="text-[#EF4444] hover:text-[#DC2626]"
                            >
                              <X className="w-5 h-5" />
                            </motion.button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  <div className="bg-[#ADC8FF]/20 p-3 rounded-[var(--radius-small)] border border-[#ADC8FF]/40">
                    <p className="text-body text-[#091A7A]">
                      <strong>Total Product Quantity:</strong> {totalQuantity.toLocaleString()} units
                    </p>
                  </div>
                </div>
              )}

              {selectedProducts.length === 0 && (
                <div className="bg-[#F59E0B]/10 border border-[#F59E0B]/30 p-4 rounded-[var(--radius-small)] text-center">
                  <p className="text-body text-[#091A7A]">No products added yet. Add products above.</p>
                </div>
              )}
            </div>
          </motion.div>

          {/* Remarks */}
          <motion.div
            className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
            whileTap={{ scale: 0.98 }}
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-[#091A7A] flex items-center justify-center">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <h2>Remarks (Optional)</h2>
            </div>

            <Textarea
              value={formData.remarks}
              onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
              placeholder="Add any relevant notes about this batch..."
              className="bg-white/70 backdrop-blur-sm border-white/30"
              rows={4}
            />
          </motion.div>

          {/* Submit Button */}
          <motion.div whileTap={{ scale: 0.95 }}>
            <Button
              type="submit"
              className="w-full h-14 bg-[#091A7A] text-white rounded-[var(--radius-standard)] shadow-interactive"
            >
              <Send className="w-5 h-5 mr-2" />
              Create Batch
            </Button>
          </motion.div>
        </form>
      </motion.div>
    </div>
  );
}
