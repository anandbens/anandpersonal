import React, { useState } from 'react';
import { motion } from 'motion/react';
import { History, Download, QrCode, Search, Calendar, Filter } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { toast } from 'sonner@2.0.3';
import { User } from '../../App';

interface GenerationHistoryProps {
  user: User;
}

interface HistoryRecord {
  id: string;
  requestNumber: string;
  plantName: string;
  plantCode: string;
  productName: string;
  productSku: string;
  batchNumber: string;
  quantity: number;
  codeMethod: string;
  generatedAt: string;
  generatedBy: string;
  printStatus: 'not_printed' | 'printed' | 'partially_printed';
  printedCount: number;
}

const mockHistory: HistoryRecord[] = [
  {
    id: '1',
    requestNumber: 'REQ-2026-004',
    plantName: 'Mumbai Plant',
    plantCode: 'MUM-01',
    productName: 'Premium Tea 500g',
    productSku: 'TEA-500-P',
    batchNumber: 'BATCH-2026-005',
    quantity: 1000,
    codeMethod: 'Alphanumeric Serial',
    generatedAt: '2026-02-08 02:15 PM',
    generatedBy: 'Admin User',
    printStatus: 'printed',
    printedCount: 1000,
  },
  {
    id: '2',
    requestNumber: 'REQ-2026-003',
    plantName: 'Bangalore Plant',
    plantCode: 'BLR-01',
    productName: 'Green Tea 100g',
    productSku: 'TEA-100-G',
    batchNumber: 'BATCH-2026-003',
    quantity: 2000,
    codeMethod: 'Custom with Prefix/Suffix',
    generatedAt: '2026-02-07 03:45 PM',
    generatedBy: 'John Doe',
    printStatus: 'not_printed',
    printedCount: 0,
  },
  {
    id: '3',
    requestNumber: 'REQ-2026-002',
    plantName: 'Delhi Plant',
    plantCode: 'DEL-01',
    productName: 'Classic Coffee 250g',
    productSku: 'COF-250-C',
    batchNumber: 'BATCH-2026-002',
    quantity: 3000,
    codeMethod: 'Product Info + MRP',
    generatedAt: '2026-02-07 11:20 AM',
    generatedBy: 'Jane Smith',
    printStatus: 'partially_printed',
    printedCount: 1500,
  },
  {
    id: '4',
    requestNumber: 'REQ-2026-001',
    plantName: 'Chennai Plant',
    plantCode: 'CHN-01',
    productName: 'Masala Chai 1kg',
    productSku: 'TEA-1000-M',
    batchNumber: 'BATCH-2026-001',
    quantity: 5000,
    codeMethod: 'Sequential Serial Number',
    generatedAt: '2026-02-06 09:30 AM',
    generatedBy: 'Admin User',
    printStatus: 'printed',
    printedCount: 5000,
  },
];

export default function GenerationHistory({ user }: GenerationHistoryProps) {
  const [history, setHistory] = useState<HistoryRecord[]>(mockHistory);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filteredHistory = history.filter(record => {
    const matchesSearch = 
      record.requestNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.batchNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      record.plantName.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesFilter = 
      filterStatus === 'all' || 
      record.printStatus === filterStatus;

    return matchesSearch && matchesFilter;
  });

  const handleDownloadCodes = (record: HistoryRecord) => {
    toast.success(`Downloading ${record.quantity.toLocaleString()} coupon codes for ${record.requestNumber}`);
  };

  const handleDownloadQRImages = (record: HistoryRecord) => {
    toast.success(`Downloading ${record.quantity.toLocaleString()} QR images for ${record.requestNumber}`);
  };

  const getPrintStatusBadge = (status: string, printed: number, total: number) => {
    switch (status) {
      case 'printed':
        return (
          <Badge className="bg-[#10B981] text-white">
            Printed ({printed.toLocaleString()})
          </Badge>
        );
      case 'partially_printed':
        return (
          <Badge className="bg-[#F59E0B] text-white">
            Partial ({printed.toLocaleString()}/{total.toLocaleString()})
          </Badge>
        );
      default:
        return (
          <Badge className="bg-[#6B7280] text-white">
            Not Printed
          </Badge>
        );
    }
  };

  return (
    <div className="max-w-7xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="mb-6">
          <h1 className="mb-2">Generation History</h1>
          <p className="text-body">View and download past QR code generations</p>
        </div>

        {/* Search and Filter */}
        <motion.div
          className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card mb-6"
          whileTap={{ scale: 0.98 }}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
                <Input
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by request, product, batch, or plant..."
                  className="pl-10 bg-white/70 backdrop-blur-sm border-white/30"
                />
              </div>
            </div>

            <div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="w-full px-4 py-3 bg-white/70 backdrop-blur-sm border border-white/30 rounded-[var(--radius-small)] outline-none focus:border-[#091A7A] transition-colors"
              >
                <option value="all">All Print Status</option>
                <option value="printed">Printed</option>
                <option value="partially_printed">Partially Printed</option>
                <option value="not_printed">Not Printed</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* History Records */}
        <div className="space-y-4">
          {filteredHistory.map((record) => (
            <motion.div
              key={record.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
            >
              <div className="flex flex-col lg:flex-row lg:items-start gap-6">
                {/* Record Details */}
                <div className="flex-1 space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-[#091A7A] mb-1">{record.requestNumber}</h3>
                      <p className="text-body">{record.productName}</p>
                    </div>
                    {getPrintStatusBadge(record.printStatus, record.printedCount, record.quantity)}
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">Plant</p>
                      <p className="text-body font-medium text-[#091A7A]">{record.plantName}</p>
                      <p className="text-tiny text-[#6B7280]">{record.plantCode}</p>
                    </div>
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">Product SKU</p>
                      <p className="text-body font-medium text-[#091A7A]">{record.productSku}</p>
                    </div>
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">Batch Number</p>
                      <p className="text-body font-medium text-[#091A7A]">{record.batchNumber}</p>
                    </div>
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">Quantity</p>
                      <p className="text-body font-medium text-[#091A7A]">{record.quantity.toLocaleString()}</p>
                    </div>
                  </div>

                  <div className="bg-[#ADC8FF]/20 p-3 rounded-[var(--radius-small)] border border-[#ADC8FF]/40">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div>
                        <p className="text-tiny text-[#9CA3AF]">Generation Method</p>
                        <p className="text-body text-[#091A7A]">{record.codeMethod}</p>
                      </div>
                      <div>
                        <p className="text-tiny text-[#9CA3AF]">Generated At</p>
                        <p className="text-body text-[#091A7A]">{record.generatedAt}</p>
                      </div>
                      <div>
                        <p className="text-tiny text-[#9CA3AF]">Generated By</p>
                        <p className="text-body text-[#091A7A]">{record.generatedBy}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex lg:flex-col gap-2 min-w-[180px]">
                  <motion.div whileTap={{ scale: 0.95 }} className="flex-1 lg:flex-none">
                    <Button
                      onClick={() => handleDownloadCodes(record)}
                      variant="outline"
                      className="w-full border-[#091A7A] text-[#091A7A] rounded-[var(--radius-small)]"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Codes CSV
                    </Button>
                  </motion.div>
                  <motion.div whileTap={{ scale: 0.95 }} className="flex-1 lg:flex-none">
                    <Button
                      onClick={() => handleDownloadQRImages(record)}
                      variant="outline"
                      className="w-full border-[#091A7A] text-[#091A7A] rounded-[var(--radius-small)]"
                    >
                      <QrCode className="w-4 h-4 mr-2" />
                      QR Images
                    </Button>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          ))}

          {filteredHistory.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-12 text-center"
            >
              <History className="w-12 h-12 text-[#9CA3AF] mx-auto mb-4" />
              <h3 className="text-[#091A7A] mb-2">No History Found</h3>
              <p className="text-body">
                {searchTerm || filterStatus !== 'all' 
                  ? 'No records match your search criteria.'
                  : 'No QR code generation history available.'}
              </p>
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
