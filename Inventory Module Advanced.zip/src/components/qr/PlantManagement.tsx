import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { User } from '../../App';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../ui/table';
import { Badge } from '../ui/badge';
import { Plus, Edit, Trash2, Factory, Search, MapPin } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface PlantManagementProps {
  user: User;
}

interface Plant {
  id: string;
  code: string;
  name: string;
  location: string;
  address: string;
  capacity: number;
  status: 'active' | 'inactive';
  manager: string;
  createdAt: string;
  updatedAt: string;
}

export default function PlantManagement({ user }: PlantManagementProps) {
  const [plants, setPlants] = useState<Plant[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingPlant, setEditingPlant] = useState<Plant | null>(null);
  const [formData, setFormData] = useState({
    code: '',
    name: '',
    location: '',
    address: '',
    capacity: '',
    manager: ''
  });

  useEffect(() => {
    loadPlants();
  }, []);

  const loadPlants = () => {
    const savedPlants = localStorage.getItem('plants');
    if (savedPlants) {
      setPlants(JSON.parse(savedPlants));
    } else {
      // Initialize with sample data
      const samplePlants: Plant[] = [
        {
          id: '1',
          code: 'PLT-MH-01',
          name: 'Mumbai Manufacturing Unit',
          location: 'Mumbai, Maharashtra',
          address: 'MIDC Industrial Area, Andheri East, Mumbai - 400093',
          capacity: 10000,
          status: 'active',
          manager: 'Rajesh Kumar',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: '2',
          code: 'PLT-KA-01',
          name: 'Bangalore Production Facility',
          location: 'Bangalore, Karnataka',
          address: 'Electronic City Phase 2, Bangalore - 560100',
          capacity: 15000,
          status: 'active',
          manager: 'Priya Sharma',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        },
        {
          id: '3',
          code: 'PLT-DL-01',
          name: 'Delhi Assembly Plant',
          location: 'New Delhi',
          address: 'Okhla Industrial Estate, Phase III, New Delhi - 110020',
          capacity: 8000,
          status: 'active',
          manager: 'Amit Singh',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        }
      ];
      localStorage.setItem('plants', JSON.stringify(samplePlants));
      setPlants(samplePlants);
    }
  };

  const savePlants = (updatedPlants: Plant[]) => {
    localStorage.setItem('plants', JSON.stringify(updatedPlants));
    setPlants(updatedPlants);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingPlant) {
      const updatedPlants = plants.map(p =>
        p.id === editingPlant.id
          ? {
              ...p,
              ...formData,
              capacity: parseInt(formData.capacity),
              updatedAt: new Date().toISOString()
            }
          : p
      );
      savePlants(updatedPlants);
      toast.success('Plant updated successfully');
    } else {
      const newPlant: Plant = {
        id: Date.now().toString(),
        ...formData,
        capacity: parseInt(formData.capacity),
        status: 'active',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      savePlants([...plants, newPlant]);
      toast.success('Plant added successfully');
    }

    setIsAddDialogOpen(false);
    setEditingPlant(null);
    setFormData({ code: '', name: '', location: '', address: '', capacity: '', manager: '' });
  };

  const handleEdit = (plant: Plant) => {
    setEditingPlant(plant);
    setFormData({
      code: plant.code,
      name: plant.name,
      location: plant.location,
      address: plant.address,
      capacity: plant.capacity.toString(),
      manager: plant.manager
    });
    setIsAddDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this plant?')) {
      const updatedPlants = plants.filter(p => p.id !== id);
      savePlants(updatedPlants);
      toast.success('Plant deleted successfully');
    }
  };

  const toggleStatus = (id: string) => {
    const updatedPlants = plants.map(p =>
      p.id === id
        ? { ...p, status: p.status === 'active' ? 'inactive' as const : 'active' as const, updatedAt: new Date().toISOString() }
        : p
    );
    savePlants(updatedPlants);
    toast.success('Plant status updated');
  };

  const filteredPlants = plants.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Manufacturing Plants</h1>
          <p className="text-gray-600 mt-1">Manage production facilities</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => {
              setEditingPlant(null);
              setFormData({ code: '', name: '', location: '', address: '', capacity: '', manager: '' });
            }}>
              <Plus className="w-4 h-4 mr-2" />
              Add Plant
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingPlant ? 'Edit Plant' : 'Add New Plant'}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="code">Plant Code *</Label>
                  <Input
                    id="code"
                    value={formData.code}
                    onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                    placeholder="PLT-XX-01"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="name">Plant Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Manufacturing Unit Name"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Location *</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="City, State"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Full Address</Label>
                <Textarea
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Complete address with pin code"
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="capacity">Daily Capacity (units) *</Label>
                  <Input
                    id="capacity"
                    type="number"
                    value={formData.capacity}
                    onChange={(e) => setFormData({ ...formData, capacity: e.target.value })}
                    placeholder="10000"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="manager">Plant Manager *</Label>
                  <Input
                    id="manager"
                    value={formData.manager}
                    onChange={(e) => setFormData({ ...formData, manager: e.target.value })}
                    placeholder="Manager name"
                    required
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  {editingPlant ? 'Update Plant' : 'Add Plant'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Plants ({filteredPlants.length})</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search plants..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Plant Code</TableHead>
                <TableHead>Plant Name</TableHead>
                <TableHead>Location</TableHead>
                <TableHead>Capacity</TableHead>
                <TableHead>Manager</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredPlants.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                    <Factory className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>No plants found</p>
                  </TableCell>
                </TableRow>
              ) : (
                filteredPlants.map((plant) => (
                  <TableRow key={plant.id}>
                    <TableCell className="font-medium">{plant.code}</TableCell>
                    <TableCell>{plant.name}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-gray-400" />
                        {plant.location}
                      </div>
                    </TableCell>
                    <TableCell>{plant.capacity.toLocaleString()} units/day</TableCell>
                    <TableCell>{plant.manager}</TableCell>
                    <TableCell>
                      <Badge
                        variant={plant.status === 'active' ? 'default' : 'secondary'}
                        className="cursor-pointer"
                        onClick={() => toggleStatus(plant.id)}
                      >
                        {plant.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(plant)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDelete(plant.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}