import React, { useState } from 'react';
import { Toaster } from './components/ui/sonner';
import LoginScreen from './components/qr/LoginScreen';
import Dashboard from './components/qr/Dashboard';
import PlantManagement from './components/qr/PlantManagement';
import ProductManagement from './components/qr/ProductManagement';
import CodeConfiguration from './components/qr/CodeConfiguration';
import BatchCreation from './components/qr/BatchCreation';
import BatchList from './components/qr/BatchList';
import BatchMappings from './components/qr/BatchMappings';
import ApprovalQueue from './components/qr/ApprovalQueue';
import QRGeneration from './components/qr/QRGeneration';
import PrintQueue from './components/qr/PrintQueue';
import GenerationHistory from './components/qr/GenerationHistory';
import Sidebar from './components/qr/Sidebar';

export type UserRole = 'inventory_admin' | 'inventory_manager' | 'plant_staff' | 'printer';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [currentScreen, setCurrentScreen] = useState<string>('dashboard');

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    setCurrentScreen('dashboard');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentScreen('dashboard');
  };

  if (!user) {
    return (
      <>
        <LoginScreen onLogin={handleLogin} />
        <Toaster position="top-right" />
      </>
    );
  }

  const renderScreen = () => {
    switch (currentScreen) {
      case 'dashboard':
        return <Dashboard user={user} />;
      case 'plants':
        return <PlantManagement user={user} />;
      case 'products':
        return <ProductManagement user={user} />;
      case 'code-config':
        return <CodeConfiguration user={user} />;
      case 'create-batch':
        return <BatchCreation user={user} />;
      case 'batches':
        return <BatchList user={user} />;
      case 'batch-mappings':
        return <BatchMappings user={user} />;
      case 'approval-queue':
        return <ApprovalQueue user={user} />;
      case 'qr-generation':
        return <QRGeneration user={user} />;
      case 'print-queue':
        return <PrintQueue user={user} />;
      case 'history':
        return <GenerationHistory user={user} />;
      default:
        return <Dashboard user={user} />;
    }
  };

  return (
    <>
      <div className="flex h-screen bg-gradient-to-br from-[#ADC8FF] to-white overflow-hidden">
        <Sidebar
          user={user}
          currentScreen={currentScreen}
          onNavigate={setCurrentScreen}
          onLogout={handleLogout}
        />
        <main className="flex-1 overflow-y-auto">
          <div className="p-6 md:p-8">
            {renderScreen()}
          </div>
        </main>
      </div>
      <Toaster position="top-right" />
    </>
  );
}