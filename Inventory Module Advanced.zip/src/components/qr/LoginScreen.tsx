import React, { useState } from 'react';
import { motion } from 'motion/react';
import { User, UserRole } from '../../App';
import { Button } from '../ui/button';
import { QrCode } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (user: User) => void;
}

const DEMO_USERS = [
  { id: '1', name: 'Admin User', email: 'admin@qrgen.com', role: 'inventory_admin' as UserRole },
  { id: '2', name: 'Manager User', email: 'manager@qrgen.com', role: 'inventory_manager' as UserRole },
  { id: '3', name: 'Plant Staff', email: 'staff@qrgen.com', role: 'plant_staff' as UserRole },
  { id: '4', name: 'Printer Operator', email: 'printer@qrgen.com', role: 'printer' as UserRole },
];

export default function LoginScreen({ onLogin }: LoginScreenProps) {
  const [selectedRole, setSelectedRole] = useState<UserRole>('inventory_admin');

  const handleLogin = () => {
    const user = DEMO_USERS.find(u => u.role === selectedRole);
    if (user) {
      onLogin(user);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#ADC8FF] to-white p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] shadow-elevated p-8 w-full max-w-md"
      >
        {/* Logo and Title */}
        <div className="flex flex-col items-center mb-8">
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="bg-gradient-to-br from-[#091A7A] to-[#0D2199] p-4 rounded-[var(--radius-standard)] mb-4"
          >
            <QrCode className="w-12 h-12 text-white" />
          </motion.div>
          <h1 className="text-[#091A7A] mb-2">QR Code Manager</h1>
          <p className="text-body text-center">Secure Loyalty Code Generation System</p>
        </div>

        {/* Role Selection */}
        <div className="space-y-4 mb-6">
          <div>
            <label className="text-body font-medium text-[#091A7A] mb-3 block">
              Select User Role (Demo)
            </label>
            <div className="grid grid-cols-1 gap-3">
              {DEMO_USERS.map((user) => (
                <motion.button
                  key={user.id}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedRole(user.role)}
                  className={`p-4 rounded-[var(--radius-standard)] border-2 transition-all text-left ${
                    selectedRole === user.role
                      ? 'border-[#091A7A] bg-[#091A7A]/10'
                      : 'border-white/30 bg-white/50 hover:border-[#ADC8FF]'
                  }`}
                >
                  <p className="text-body font-medium text-[#091A7A] mb-1">{user.name}</p>
                  <p className="text-tiny text-[#6B7280]">{user.email}</p>
                </motion.button>
              ))}
            </div>
          </div>

          <div className="bg-[#ADC8FF]/20 border border-[#ADC8FF]/40 rounded-[var(--radius-standard)] p-4">
            <p className="text-small text-[#091A7A]">
              <strong>Demo Mode:</strong> Select a role to explore the system. Each role has different permissions and views.
            </p>
          </div>
        </div>

        {/* Login Button */}
        <motion.div whileTap={{ scale: 0.95 }}>
          <Button 
            onClick={handleLogin}
            className="w-full h-14 bg-gradient-to-r from-[#091A7A] to-[#0D2199] text-white rounded-[var(--radius-standard)] shadow-interactive"
          >
            Login as {DEMO_USERS.find(u => u.role === selectedRole)?.name}
          </Button>
        </motion.div>

        {/* Footer */}
        <div className="mt-8 pt-6 border-t border-white/20">
          <p className="text-tiny text-[#9CA3AF] text-center">
            QR Code Generation & Management System v1.0
          </p>
        </div>
      </motion.div>
    </div>
  );
}
