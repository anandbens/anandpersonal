import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Printer, Download, RotateCcw, CheckCircle2, Clock, Grid3x3 } from 'lucide-react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { toast } from 'sonner@2.0.3';
import { User } from '../../App';

interface PrintQueueProps {
  user: User;
}

interface PrintJob {
  id: string;
  requestNumber: string;
  productName: string;
  productSku: string;
  batchNumber: string;
  totalQRCodes: number;
  printedCount: number;
  sheetFormat: string;
  status: 'pending' | 'printing' | 'printed';
  addedAt: string;
  printedAt?: string;
}

const mockPrintJobs: PrintJob[] = [
  {
    id: '1',
    requestNumber: 'REQ-2026-004',
    productName: 'Premium Tea 500g',
    productSku: 'TEA-500-P',
    batchNumber: 'BATCH-2026-005',
    totalQRCodes: 1000,
    printedCount: 0,
    sheetFormat: 'A4 - 21 per sheet',
    status: 'pending',
    addedAt: '2026-02-08 02:30 PM',
  },
  {
    id: '2',
    requestNumber: 'REQ-2026-005',
    productName: 'Classic Coffee 250g',
    productSku: 'COF-250-C',
    batchNumber: 'BATCH-2026-006',
    totalQRCodes: 500,
    printedCount: 500,
    sheetFormat: 'A4 - 21 per sheet',
    status: 'printed',
    addedAt: '2026-02-08 11:00 AM',
    printedAt: '2026-02-08 11:45 AM',
  },
  {
    id: '3',
    requestNumber: 'REQ-2026-006',
    productName: 'Green Tea 100g',
    productSku: 'TEA-100-G',
    batchNumber: 'BATCH-2026-007',
    totalQRCodes: 750,
    printedCount: 0,
    sheetFormat: 'A4 - 21 per sheet',
    status: 'pending',
    addedAt: '2026-02-08 01:15 PM',
  },
];

export default function PrintQueue({ user }: PrintQueueProps) {
  const [jobs, setJobs] = useState<PrintJob[]>(mockPrintJobs);
  const [printingId, setPrintingId] = useState<string | null>(null);
  const [selectedFormat, setSelectedFormat] = useState('a4-21');

  const handlePrint = async (jobId: string) => {
    setPrintingId(jobId);
    const job = jobs.find(j => j.id === jobId);
    
    if (!job) return;

    // Update status to printing
    setJobs(jobs.map(j => j.id === jobId ? { ...j, status: 'printing' as const } : j));

    // Simulate printing process
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Mark as printed
    setJobs(jobs.map(j => 
      j.id === jobId 
        ? { 
            ...j, 
            status: 'printed' as const, 
            printedCount: j.totalQRCodes,
            printedAt: new Date().toLocaleString('en-US', {
              year: 'numeric',
              month: '2-digit',
              day: '2-digit',
              hour: '2-digit',
              minute: '2-digit',
              hour12: true
            })
          } 
        : j
    ));

    setPrintingId(null);
    toast.success(`Print job completed: ${job.totalQRCodes} QR codes printed`);
  };

  const handleReprint = (jobId: string) => {
    const job = jobs.find(j => j.id === jobId);
    if (job) {
      toast.info(`Reprinting ${job.totalQRCodes} QR codes for ${job.requestNumber}`);
      handlePrint(jobId);
    }
  };

  const handleDownloadPrintReady = (job: PrintJob) => {
    toast.success(`Downloading print-ready file for ${job.requestNumber}`);
  };

  const canPrint = user.role === 'printer' || user.role === 'inventory_admin';

  const sheetsRequired = (totalCodes: number, codesPerSheet: number = 21) => {
    return Math.ceil(totalCodes / codesPerSheet);
  };

  return (
    <div className="max-w-7xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="mb-6">
          <h1 className="mb-2">Print Queue</h1>
          <p className="text-body">Manage QR code printing for self-adhesive A4 sheets</p>
        </div>

        {/* Print Format Selector */}
        <motion.div
          className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card mb-6"
          whileTap={{ scale: 0.98 }}
        >
          <div className="flex items-center gap-3 mb-4">
            <Grid3x3 className="w-5 h-5 text-[#091A7A]" />
            <h2>Print Format Configuration</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {[
              { value: 'a4-21', label: 'A4 - 21 per sheet (3x7)', description: '63.5mm x 38.1mm' },
              { value: 'a4-24', label: 'A4 - 24 per sheet (3x8)', description: '63.5mm x 33.9mm' },
              { value: 'a4-40', label: 'A4 - 40 per sheet (5x8)', description: '48.5mm x 25.4mm' },
            ].map((format) => (
              <motion.button
                key={format.value}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedFormat(format.value)}
                className={`p-4 rounded-[var(--radius-small)] border-2 transition-all text-left ${
                  selectedFormat === format.value
                    ? 'border-[#091A7A] bg-[#091A7A]/10'
                    : 'border-white/30 bg-white/50'
                }`}
              >
                <p className="text-body font-medium text-[#091A7A] mb-1">{format.label}</p>
                <p className="text-tiny text-[#6B7280]">{format.description}</p>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Print Jobs */}
        <div className="grid gap-4">
          {jobs.map((job) => (
            <motion.div
              key={job.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
            >
              <div className="flex flex-col lg:flex-row lg:items-start gap-6">
                {/* Job Details */}
                <div className="flex-1 space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-[#091A7A] mb-1">{job.requestNumber}</h3>
                      <p className="text-body">{job.productName}</p>
                    </div>
                    <Badge
                      className={`${
                        job.status === 'pending'
                          ? 'bg-[#F59E0B] text-white'
                          : job.status === 'printing'
                          ? 'bg-[#091A7A] text-white'
                          : 'bg-[#10B981] text-white'
                      }`}
                    >
                      {job.status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
                      {job.status === 'printing' && <Printer className="w-3 h-3 mr-1" />}
                      {job.status === 'printed' && <CheckCircle2 className="w-3 h-3 mr-1" />}
                      {job.status.toUpperCase()}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">Total QR Codes</p>
                      <p className="text-body font-medium text-[#091A7A]">{job.totalQRCodes.toLocaleString()}</p>
                    </div>
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">Sheets Required</p>
                      <p className="text-body font-medium text-[#091A7A]">{sheetsRequired(job.totalQRCodes)}</p>
                    </div>
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">SKU</p>
                      <p className="text-body font-medium text-[#091A7A]">{job.productSku}</p>
                    </div>
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">Batch</p>
                      <p className="text-body font-medium text-[#091A7A]">{job.batchNumber}</p>
                    </div>
                  </div>

                  <div className="bg-[#ADC8FF]/20 p-3 rounded-[var(--radius-small)] border border-[#ADC8FF]/40">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
                      <div>
                        <p className="text-tiny text-[#9CA3AF]">Sheet Format</p>
                        <p className="text-body text-[#091A7A]">{job.sheetFormat}</p>
                      </div>
                      <div>
                        <p className="text-tiny text-[#9CA3AF]">Added to Queue</p>
                        <p className="text-body text-[#091A7A]">{job.addedAt}</p>
                      </div>
                      {job.printedAt && (
                        <div>
                          <p className="text-tiny text-[#9CA3AF]">Printed At</p>
                          <p className="text-body text-[#091A7A]">{job.printedAt}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {job.status === 'printed' && (
                    <div className="bg-[#10B981]/10 border border-[#10B981]/30 p-3 rounded-[var(--radius-small)] flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#10B981]" />
                      <p className="text-body text-[#10B981]">
                        {job.printedCount.toLocaleString()} / {job.totalQRCodes.toLocaleString()} codes printed
                      </p>
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex lg:flex-col gap-2 min-w-[180px]">
                  <motion.div whileTap={{ scale: 0.95 }} className="flex-1 lg:flex-none">
                    <Button
                      onClick={() => handleDownloadPrintReady(job)}
                      variant="outline"
                      className="w-full border-[#091A7A] text-[#091A7A] rounded-[var(--radius-small)]"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                  </motion.div>

                  {canPrint && job.status === 'pending' && (
                    <motion.div whileTap={{ scale: 0.95 }} className="flex-1 lg:flex-none">
                      <Button
                        onClick={() => handlePrint(job.id)}
                        disabled={printingId === job.id}
                        className="w-full bg-[#091A7A] text-white rounded-[var(--radius-small)]"
                      >
                        <Printer className="w-4 h-4 mr-2" />
                        {printingId === job.id ? 'Printing...' : 'Print'}
                      </Button>
                    </motion.div>
                  )}

                  {canPrint && job.status === 'printed' && (
                    <motion.div whileTap={{ scale: 0.95 }} className="flex-1 lg:flex-none">
                      <Button
                        onClick={() => handleReprint(job.id)}
                        variant="outline"
                        className="w-full border-[#091A7A] text-[#091A7A] rounded-[var(--radius-small)]"
                      >
                        <RotateCcw className="w-4 h-4 mr-2" />
                        Reprint
                      </Button>
                    </motion.div>
                  )}

                  {!canPrint && (
                    <div className="text-tiny text-[#9CA3AF] italic text-center">
                      Print access required
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ))}

          {jobs.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-12 text-center"
            >
              <Printer className="w-12 h-12 text-[#9CA3AF] mx-auto mb-4" />
              <h3 className="text-[#091A7A] mb-2">Print Queue Empty</h3>
              <p className="text-body">There are no print jobs in the queue.</p>
            </motion.div>
          )}
        </div>

        {/* Printer Connection Status */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mt-6 bg-white/70 backdrop-blur-sm border border-white/30 rounded-[var(--radius-standard)] p-4"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-[#10B981] animate-pulse" />
              <p className="text-body text-[#091A7A]">Printer Connected: HP LaserJet Pro M404dn</p>
            </div>
            <p className="text-tiny text-[#6B7280]">Ready to print</p>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
