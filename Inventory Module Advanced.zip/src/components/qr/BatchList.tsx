import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Download, Search, Filter, Calendar, Package, X } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Badge } from '../ui/badge';
import { toast } from 'sonner@2.0.3';
import { User } from '../../App';

interface BatchListProps {
  user: User;
}

interface Batch {
  id: string;
  batchName: string;
  plantName: string;
  plantCode: string;
  totalCoupons: number;
  products: Array<{ name: string; externalId: string; quantity: number }>;
  referenceId?: string;
  createdAt: string;
  status: 'generating' | 'completed' | 'failed';
}

const mockBatches: Batch[] = [
  {
    id: 'BATCH-1707481234567',
    batchName: 'TEA-BATCH-FEB-2026',
    plantName: 'Mumbai Plant',
    plantCode: 'MUM-01',
    totalCoupons: 5000,
    products: [
      { name: 'Premium Tea 500g', externalId: 'P001', quantity: 3000 },
      { name: 'Green Tea 100g', externalId: 'P003', quantity: 2000 },
    ],
    referenceId: 'REF-2026-001',
    createdAt: '2026-02-08 10:30 AM',
    status: 'completed',
  },
  {
    id: 'BATCH-1707481234568',
    batchName: 'COFFEE-BATCH-FEB-2026',
    plantName: 'Delhi Plant',
    plantCode: 'DEL-01',
    totalCoupons: 3000,
    products: [
      { name: 'Classic Coffee 250g', externalId: 'P002', quantity: 3000 },
    ],
    referenceId: 'REF-2026-002',
    createdAt: '2026-02-07 02:15 PM',
    status: 'completed',
  },
  {
    id: 'BATCH-1707481234569',
    batchName: 'CHAI-BATCH-FEB-2026',
    plantName: 'Bangalore Plant',
    plantCode: 'BLR-01',
    totalCoupons: 2000,
    products: [
      { name: 'Masala Chai 1kg', externalId: 'P004', quantity: 2000 },
    ],
    createdAt: '2026-02-06 09:00 AM',
    status: 'generating',
  },
];

export default function BatchList({ user }: BatchListProps) {
  const [batches] = useState<Batch[]>(mockBatches);
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    batchId: '',
    batchName: '',
    productId: '',
    dateFrom: '',
    dateTo: '',
  });

  const handleDownload = (batch: Batch) => {
    if (batch.status !== 'completed') {
      toast.error('Batch generation is still in progress');
      return;
    }

    toast.success(
      `Downloading ${batch.totalCoupons.toLocaleString()} coupons for batch ${batch.batchName}`,
      { duration: 3000 }
    );
  };

  const handleDownloadPDF = (batch: Batch) => {
    if (batch.status !== 'completed') {
      toast.error('Batch generation is still in progress');
      return;
    }

    toast.success(`Downloading print-ready PDF for batch ${batch.batchName}`);
  };

  const applyFilters = (batch: Batch) => {
    if (filters.batchId && !batch.id.toLowerCase().includes(filters.batchId.toLowerCase())) {
      return false;
    }
    if (filters.batchName && !batch.batchName.toLowerCase().includes(filters.batchName.toLowerCase())) {
      return false;
    }
    if (filters.productId && !batch.products.some(p => p.externalId.toLowerCase().includes(filters.productId.toLowerCase()))) {
      return false;
    }
    // Date filtering would be implemented here
    return true;
  };

  const filteredBatches = batches.filter(batch => {
    const matchesSearch =
      batch.batchName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      batch.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      batch.plantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      batch.products.some(p => 
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.externalId.toLowerCase().includes(searchTerm.toLowerCase())
      );

    const matchesFilters = applyFilters(batch);

    return matchesSearch && matchesFilters;
  });

  const clearFilters = () => {
    setFilters({
      batchId: '',
      batchName: '',
      productId: '',
      dateFrom: '',
      dateTo: '',
    });
    toast.info('Filters cleared');
  };

  return (
    <div className="max-w-7xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="mb-6">
          <h1 className="mb-2">Batches</h1>
          <p className="text-body">View and download coupon batches</p>
        </div>

        {/* Search and Filter */}
        <motion.div
          className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card mb-6"
          whileTap={{ scale: 0.98 }}
        >
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#6B7280]" />
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search batches by ID, name, plant, or product..."
                className="pl-10 bg-white/70 backdrop-blur-sm border-white/30"
              />
            </div>

            <motion.div whileTap={{ scale: 0.95 }}>
              <Button
                onClick={() => setShowFilters(!showFilters)}
                variant="outline"
                className="border-[#091A7A] text-[#091A7A] rounded-[var(--radius-small)]"
              >
                <Filter className="w-4 h-4 mr-2" />
                {showFilters ? 'Hide Filters' : 'Show Filters'}
              </Button>
            </motion.div>
          </div>

          {/* Filter Panel */}
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 pt-4 border-t border-white/20"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
                <div>
                  <Label htmlFor="filterBatchId">Batch ID</Label>
                  <Input
                    id="filterBatchId"
                    value={filters.batchId}
                    onChange={(e) => setFilters({ ...filters, batchId: e.target.value })}
                    placeholder="BATCH-XXX"
                    className="mt-2 bg-white/70 backdrop-blur-sm border-white/30"
                  />
                </div>

                <div>
                  <Label htmlFor="filterBatchName">Batch Name</Label>
                  <Input
                    id="filterBatchName"
                    value={filters.batchName}
                    onChange={(e) => setFilters({ ...filters, batchName: e.target.value })}
                    placeholder="Batch name"
                    className="mt-2 bg-white/70 backdrop-blur-sm border-white/30"
                  />
                </div>

                <div>
                  <Label htmlFor="filterProductId">Product External ID</Label>
                  <Input
                    id="filterProductId"
                    value={filters.productId}
                    onChange={(e) => setFilters({ ...filters, productId: e.target.value })}
                    placeholder="P001"
                    className="mt-2 bg-white/70 backdrop-blur-sm border-white/30"
                  />
                </div>

                <div>
                  <Label htmlFor="dateFrom">Creation Date From</Label>
                  <Input
                    id="dateFrom"
                    type="date"
                    value={filters.dateFrom}
                    onChange={(e) => setFilters({ ...filters, dateFrom: e.target.value })}
                    className="mt-2 bg-white/70 backdrop-blur-sm border-white/30"
                  />
                </div>

                <div>
                  <Label htmlFor="dateTo">Creation Date To</Label>
                  <Input
                    id="dateTo"
                    type="date"
                    value={filters.dateTo}
                    onChange={(e) => setFilters({ ...filters, dateTo: e.target.value })}
                    className="mt-2 bg-white/70 backdrop-blur-sm border-white/30"
                  />
                </div>
              </div>

              <motion.div whileTap={{ scale: 0.95 }}>
                <Button
                  onClick={clearFilters}
                  variant="outline"
                  className="border-[#EF4444] text-[#EF4444] hover:bg-[#EF4444]/10"
                >
                  <X className="w-4 h-4 mr-2" />
                  Clear Filters
                </Button>
              </motion.div>
            </motion.div>
          )}
        </motion.div>

        {/* Batch List */}
        <div className="space-y-4">
          {filteredBatches.map((batch) => (
            <motion.div
              key={batch.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
            >
              <div className="flex flex-col lg:flex-row lg:items-start gap-6">
                {/* Batch Details */}
                <div className="flex-1 space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-[#091A7A] mb-1">{batch.batchName}</h3>
                      <p className="text-tiny text-[#9CA3AF]">Batch ID: {batch.id}</p>
                    </div>
                    <Badge
                      className={`${
                        batch.status === 'completed'
                          ? 'bg-[#10B981] text-white'
                          : batch.status === 'generating'
                          ? 'bg-[#F59E0B] text-white'
                          : 'bg-[#EF4444] text-white'
                      }`}
                    >
                      {batch.status.toUpperCase()}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">Plant</p>
                      <p className="text-body font-medium text-[#091A7A]">{batch.plantName}</p>
                      <p className="text-tiny text-[#6B7280]">{batch.plantCode}</p>
                    </div>
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">Total Coupons</p>
                      <p className="text-body font-medium text-[#091A7A]">{batch.totalCoupons.toLocaleString()}</p>
                    </div>
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">Reference ID</p>
                      <p className="text-body font-medium text-[#091A7A]">{batch.referenceId || 'N/A'}</p>
                    </div>
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">Created</p>
                      <p className="text-body font-medium text-[#091A7A]">{batch.createdAt}</p>
                    </div>
                  </div>

                  {/* Products */}
                  <div className="bg-[#ADC8FF]/20 p-3 rounded-[var(--radius-small)] border border-[#ADC8FF]/40">
                    <p className="text-tiny text-[#9CA3AF] mb-2">Products in Batch:</p>
                    <div className="space-y-1">
                      {batch.products.map((product, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <p className="text-body text-[#091A7A]">
                            {product.name} <span className="text-[#6B7280]">({product.externalId})</span>
                          </p>
                          <p className="text-body font-medium text-[#091A7A]">
                            {product.quantity.toLocaleString()} units
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex lg:flex-col gap-2 min-w-[180px]">
                  <motion.div whileTap={{ scale: 0.95 }} className="flex-1 lg:flex-none">
                    <Button
                      onClick={() => handleDownload(batch)}
                      disabled={batch.status !== 'completed'}
                      className="w-full bg-[#091A7A] text-white rounded-[var(--radius-small)]"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download CSV
                    </Button>
                  </motion.div>
                  <motion.div whileTap={{ scale: 0.95 }} className="flex-1 lg:flex-none">
                    <Button
                      onClick={() => handleDownloadPDF(batch)}
                      disabled={batch.status !== 'completed'}
                      variant="outline"
                      className="w-full border-[#091A7A] text-[#091A7A] rounded-[var(--radius-small)]"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download PDF
                    </Button>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          ))}

          {filteredBatches.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-12 text-center"
            >
              <Package className="w-12 h-12 text-[#9CA3AF] mx-auto mb-4" />
              <h3 className="text-[#091A7A] mb-2">No Batches Found</h3>
              <p className="text-body">
                {searchTerm || Object.values(filters).some(f => f) 
                  ? 'No batches match your search criteria.'
                  : 'No batches have been created yet.'}
              </p>
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
