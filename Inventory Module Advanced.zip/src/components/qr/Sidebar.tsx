import React from 'react';
import { motion } from 'motion/react';
import { 
  LayoutDashboard, 
  Factory, 
  Package, 
  Settings,
  PlusCircle, 
  Layers,
  Link2,
  FileCheck, 
  QrCode, 
  Printer, 
  History, 
  LogOut 
} from 'lucide-react';
import { Button } from '../ui/button';
import { User, UserRole } from '../../App';

interface SidebarProps {
  user: User;
  currentScreen: string;
  onNavigate: (screen: string) => void;
  onLogout: () => void;
}

const navigationItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['inventory_admin', 'inventory_manager', 'plant_staff', 'printer'] },
  { id: 'plants', label: 'Plants', icon: Factory, roles: ['inventory_admin', 'inventory_manager'] },
  { id: 'products', label: 'Products', icon: Package, roles: ['inventory_admin', 'inventory_manager'] },
  { id: 'code-config', label: 'Code Configuration', icon: Settings, roles: ['inventory_admin'] },
  { id: 'create-batch', label: 'Create Batch', icon: PlusCircle, roles: ['inventory_admin', 'inventory_manager', 'plant_staff'] },
  { id: 'batches', label: 'Batches', icon: Layers, roles: ['inventory_admin', 'inventory_manager', 'plant_staff'] },
  { id: 'batch-mappings', label: 'Batch Mappings', icon: Link2, roles: ['inventory_admin', 'inventory_manager'] },
  { id: 'approval-queue', label: 'Approval Queue', icon: FileCheck, roles: ['inventory_admin', 'inventory_manager'] },
  { id: 'qr-generation', label: 'Generate QR', icon: QrCode, roles: ['inventory_admin', 'inventory_manager'] },
  { id: 'print-queue', label: 'Print Queue', icon: Printer, roles: ['inventory_admin', 'printer'] },
  { id: 'history', label: 'History', icon: History, roles: ['inventory_admin', 'inventory_manager', 'plant_staff'] },
];

export default function Sidebar({ user, currentScreen, onNavigate, onLogout }: SidebarProps) {
  const getRoleLabel = (role: UserRole) => {
    const labels: Record<UserRole, string> = {
      'inventory_admin': 'Admin',
      'inventory_manager': 'Manager',
      'plant_staff': 'Plant Staff',
      'printer': 'Printer Operator'
    };
    return labels[role] || role;
  };

  const accessibleItems = navigationItems.filter(item => 
    item.roles.includes(user.role)
  );

  return (
    <aside className="w-72 bg-gradient-to-br from-[#091A7A] to-[#0D2199] text-white flex flex-col shadow-elevated">
      {/* Logo Header */}
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <motion.div 
            whileTap={{ scale: 0.95 }}
            className="bg-white/10 p-3 rounded-[var(--radius-standard)]"
          >
            <QrCode className="w-8 h-8" />
          </motion.div>
          <div>
            <h1 className="text-[20px] font-semibold">QR Manager</h1>
            <p className="text-[10px] text-[#ADC8FF]">Loyalty Code System</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        {accessibleItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentScreen === item.id;
          
          return (
            <motion.button
              key={item.id}
              whileTap={{ scale: 0.95 }}
              onClick={() => onNavigate(item.id)}
              className={`
                w-full flex items-center gap-3 px-4 py-3 rounded-[var(--radius-standard)]
                transition-all duration-200
                ${isActive 
                  ? 'bg-white text-[#091A7A] shadow-interactive' 
                  : 'text-[#ADC8FF] hover:bg-white/10'
                }
              `}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium text-[14px]">{item.label}</span>
            </motion.button>
          );
        })}
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-white/10">
        <div className="bg-white/10 rounded-[var(--radius-standard)] p-4 mb-3 backdrop-blur-sm">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#ADC8FF] to-[#7BA7FF] flex items-center justify-center font-semibold text-[#091A7A]">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-[14px] truncate">{user.name}</p>
              <p className="text-[10px] text-[#ADC8FF]">{getRoleLabel(user.role)}</p>
            </div>
          </div>
        </div>
        
        <motion.div whileTap={{ scale: 0.95 }}>
          <Button
            onClick={onLogout}
            variant="outline"
            className="w-full bg-white/5 border-white/20 text-white hover:bg-white/10 rounded-[var(--radius-standard)]"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </motion.div>
      </div>
    </aside>
  );
}