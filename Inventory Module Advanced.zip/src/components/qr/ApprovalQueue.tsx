import React, { useState } from 'react';
import { motion } from 'motion/react';
import { CheckCircle, XCircle, Clock, Package, Factory, Hash, Eye } from 'lucide-react';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { toast } from 'sonner@2.0.3';
import { User } from '../../App';

interface ApprovalQueueProps {
  user: User;
}

interface Request {
  id: string;
  requestNumber: string;
  plantName: string;
  plantCode: string;
  productName: string;
  productSku: string;
  batchNumber: string;
  quantity: number;
  codeMethod: string;
  status: 'pending' | 'approved' | 'rejected';
  requestedBy: string;
  requestedAt: string;
  notes?: string;
}

const mockRequests: Request[] = [
  {
    id: '1',
    requestNumber: 'REQ-2026-001',
    plantName: 'Mumbai Plant',
    plantCode: 'MUM-01',
    productName: 'Premium Tea 500g',
    productSku: 'TEA-500-P',
    batchNumber: 'BATCH-2026-001',
    quantity: 5000,
    codeMethod: 'Alphanumeric Serial',
    status: 'pending',
    requestedBy: 'John Doe',
    requestedAt: '2026-02-08 10:30 AM',
    notes: 'Urgent - Production deadline: Feb 15',
  },
  {
    id: '2',
    requestNumber: 'REQ-2026-002',
    plantName: 'Delhi Plant',
    plantCode: 'DEL-01',
    productName: 'Classic Coffee 250g',
    productSku: 'COF-250-C',
    batchNumber: 'BATCH-2026-002',
    quantity: 3000,
    codeMethod: 'Product Info + MRP',
    status: 'pending',
    requestedBy: 'Jane Smith',
    requestedAt: '2026-02-08 09:15 AM',
  },
  {
    id: '3',
    requestNumber: 'REQ-2026-003',
    plantName: 'Bangalore Plant',
    plantCode: 'BLR-01',
    productName: 'Green Tea 100g',
    productSku: 'TEA-100-G',
    batchNumber: 'BATCH-2026-003',
    quantity: 2000,
    codeMethod: 'Custom with Prefix/Suffix',
    status: 'approved',
    requestedBy: 'Mike Johnson',
    requestedAt: '2026-02-07 04:20 PM',
  },
];

export default function ApprovalQueue({ user }: ApprovalQueueProps) {
  const [requests, setRequests] = useState<Request[]>(mockRequests);
  const [selectedRequest, setSelectedRequest] = useState<Request | null>(null);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');

  const handleApprove = (requestId: string) => {
    setRequests(requests.map(req => 
      req.id === requestId ? { ...req, status: 'approved' as const } : req
    ));
    toast.success('Request approved successfully');
    setSelectedRequest(null);
  };

  const handleReject = (requestId: string) => {
    setRequests(requests.map(req => 
      req.id === requestId ? { ...req, status: 'rejected' as const } : req
    ));
    toast.error('Request rejected');
    setSelectedRequest(null);
  };

  const filteredRequests = filter === 'all' 
    ? requests 
    : requests.filter(req => req.status === filter);

  const canApprove = user.role === 'inventory_admin' || user.role === 'inventory_manager';

  return (
    <div className="max-w-7xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="mb-6">
          <h1 className="mb-2">Approval Queue</h1>
          <p className="text-body">Review and approve QR generation requests</p>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {['all', 'pending', 'approved', 'rejected'].map((filterOption) => (
            <motion.button
              key={filterOption}
              whileTap={{ scale: 0.95 }}
              onClick={() => setFilter(filterOption as typeof filter)}
              className={`px-6 py-3 rounded-[var(--radius-standard)] transition-all whitespace-nowrap ${
                filter === filterOption
                  ? 'bg-[#091A7A] text-white shadow-interactive'
                  : 'bg-white/70 backdrop-blur-sm text-[#091A7A] border border-white/30'
              }`}
            >
              {filterOption.charAt(0).toUpperCase() + filterOption.slice(1)}
            </motion.button>
          ))}
        </div>

        {/* Requests Grid */}
        <div className="grid gap-4">
          {filteredRequests.map((request) => (
            <motion.div
              key={request.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
            >
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                <div className="flex-1 space-y-4">
                  {/* Header */}
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-[#091A7A] mb-1">{request.requestNumber}</h3>
                      <p className="text-tiny text-[#9CA3AF]">
                        Requested by {request.requestedBy} • {request.requestedAt}
                      </p>
                    </div>
                    <Badge
                      className={`${
                        request.status === 'pending'
                          ? 'bg-[#F59E0B] text-white'
                          : request.status === 'approved'
                          ? 'bg-[#10B981] text-white'
                          : 'bg-[#EF4444] text-white'
                      }`}
                    >
                      {request.status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
                      {request.status === 'approved' && <CheckCircle className="w-3 h-3 mr-1" />}
                      {request.status === 'rejected' && <XCircle className="w-3 h-3 mr-1" />}
                      {request.status.toUpperCase()}
                    </Badge>
                  </div>

                  {/* Details Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <div className="flex items-center gap-2 mb-2">
                        <Factory className="w-4 h-4 text-[#091A7A]" />
                        <p className="text-tiny text-[#9CA3AF]">Plant</p>
                      </div>
                      <p className="text-body font-medium text-[#091A7A]">{request.plantName}</p>
                      <p className="text-tiny text-[#6B7280]">{request.plantCode}</p>
                    </div>

                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <div className="flex items-center gap-2 mb-2">
                        <Package className="w-4 h-4 text-[#091A7A]" />
                        <p className="text-tiny text-[#9CA3AF]">Product</p>
                      </div>
                      <p className="text-body font-medium text-[#091A7A]">{request.productName}</p>
                      <p className="text-tiny text-[#6B7280]">SKU: {request.productSku}</p>
                    </div>

                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <div className="flex items-center gap-2 mb-2">
                        <Hash className="w-4 h-4 text-[#091A7A]" />
                        <p className="text-tiny text-[#9CA3AF]">Generation Details</p>
                      </div>
                      <p className="text-body font-medium text-[#091A7A]">{request.quantity.toLocaleString()} codes</p>
                      <p className="text-tiny text-[#6B7280]">{request.codeMethod}</p>
                    </div>
                  </div>

                  {/* Batch & Notes */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <p className="text-tiny text-[#9CA3AF]">Batch:</p>
                      <p className="text-body text-[#091A7A]">{request.batchNumber}</p>
                    </div>
                    {request.notes && (
                      <div className="bg-[#F59E0B]/10 border border-[#F59E0B]/30 p-3 rounded-[var(--radius-small)]">
                        <p className="text-tiny text-[#091A7A]">{request.notes}</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Actions */}
                {canApprove && request.status === 'pending' && (
                  <div className="flex lg:flex-col gap-2 min-w-[140px]">
                    <motion.div whileTap={{ scale: 0.95 }} className="flex-1 lg:flex-none">
                      <Button
                        onClick={() => handleApprove(request.id)}
                        className="w-full bg-[#10B981] text-white hover:bg-[#10B981]/90 rounded-[var(--radius-small)]"
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Approve
                      </Button>
                    </motion.div>
                    <motion.div whileTap={{ scale: 0.95 }} className="flex-1 lg:flex-none">
                      <Button
                        onClick={() => handleReject(request.id)}
                        variant="outline"
                        className="w-full border-[#EF4444] text-[#EF4444] hover:bg-[#EF4444]/10 rounded-[var(--radius-small)]"
                      >
                        <XCircle className="w-4 h-4 mr-2" />
                        Reject
                      </Button>
                    </motion.div>
                  </div>
                )}

                {!canApprove && (
                  <div className="text-tiny text-[#9CA3AF] italic">
                    Awaiting approval
                  </div>
                )}
              </div>
            </motion.div>
          ))}

          {filteredRequests.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-12 text-center"
            >
              <Clock className="w-12 h-12 text-[#9CA3AF] mx-auto mb-4" />
              <h3 className="text-[#091A7A] mb-2">No Requests Found</h3>
              <p className="text-body">There are no {filter !== 'all' ? filter : ''} requests at this time.</p>
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
