
  # Inventory Module Advanced

  This is a code bundle for Inventory Module Advanced. The original project is available at https://www.figma.com/design/IUB3q0rHN4YKNQs43OG3Vz/Inventory-Module-Advanced.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  