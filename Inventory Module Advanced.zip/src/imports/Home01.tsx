import { imgHome01 } from "./svg-5stpn";

export default function Home01() {
  return (
    <div className="relative size-full" data-name="home-01">
      <img className="block max-w-none size-full" src={imgHome01} />
    </div>
  );
}