import React, { useState } from 'react';
import { motion } from 'motion/react';
import { QrCode, Download, Play, Package, Check } from 'lucide-react';
import { Button } from '../ui/button';
import { Progress } from '../ui/progress';
import { toast } from 'sonner@2.0.3';
import { User } from '../../App';

interface QRGenerationProps {
  user: User;
}

interface ApprovedRequest {
  id: string;
  requestNumber: string;
  plantName: string;
  productName: string;
  productSku: string;
  batchNumber: string;
  quantity: number;
  codeMethod: string;
  generated: boolean;
  generatedCount?: number;
}

const mockApprovedRequests: ApprovedRequest[] = [
  {
    id: '3',
    requestNumber: 'REQ-2026-003',
    plantName: 'Bangalore Plant',
    productName: 'Green Tea 100g',
    productSku: 'TEA-100-G',
    batchNumber: 'BATCH-2026-003',
    quantity: 2000,
    codeMethod: 'Custom with Prefix/Suffix',
    generated: false,
  },
  {
    id: '4',
    requestNumber: 'REQ-2026-004',
    plantName: 'Mumbai Plant',
    productName: 'Premium Tea 500g',
    productSku: 'TEA-500-P',
    batchNumber: 'BATCH-2026-005',
    quantity: 1000,
    codeMethod: 'Alphanumeric Serial',
    generated: true,
    generatedCount: 1000,
  },
];

export default function QRGeneration({ user }: QRGenerationProps) {
  const [requests, setRequests] = useState<ApprovedRequest[]>(mockApprovedRequests);
  const [generatingId, setGeneratingId] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);

  const handleGenerate = async (requestId: string) => {
    setGeneratingId(requestId);
    setProgress(0);

    // Simulate QR code generation
    const request = requests.find(r => r.id === requestId);
    if (!request) return;

    const totalCodes = request.quantity;
    const batchSize = 100;
    const batches = Math.ceil(totalCodes / batchSize);

    for (let i = 0; i < batches; i++) {
      await new Promise(resolve => setTimeout(resolve, 200));
      setProgress(((i + 1) / batches) * 100);
    }

    setRequests(requests.map(req =>
      req.id === requestId
        ? { ...req, generated: true, generatedCount: req.quantity }
        : req
    ));

    setGeneratingId(null);
    setProgress(0);
    toast.success(`Successfully generated ${totalCodes.toLocaleString()} QR codes`);
  };

  const handleDownloadCodes = (request: ApprovedRequest) => {
    toast.success(`Downloading ${request.generatedCount?.toLocaleString()} coupon codes as CSV`);
  };

  const handleDownloadQRImages = (request: ApprovedRequest) => {
    toast.success(`Downloading ${request.generatedCount?.toLocaleString()} QR code images`);
  };

  return (
    <div className="max-w-7xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="mb-6">
          <h1 className="mb-2">QR Code Generation</h1>
          <p className="text-body">Generate QR codes for approved requests</p>
        </div>

        <div className="grid gap-4">
          {requests.map((request) => (
            <motion.div
              key={request.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-6 shadow-card"
            >
              <div className="flex flex-col lg:flex-row lg:items-start gap-6">
                {/* Request Details */}
                <div className="flex-1 space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-[#091A7A] mb-1">{request.requestNumber}</h3>
                      <div className="flex items-center gap-2">
                        <Package className="w-4 h-4 text-[#6B7280]" />
                        <p className="text-body">{request.productName}</p>
                      </div>
                    </div>
                    {request.generated && (
                      <div className="bg-[#10B981] text-white px-3 py-1 rounded-full flex items-center gap-2">
                        <Check className="w-4 h-4" />
                        <span className="text-tiny">Generated</span>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">Plant</p>
                      <p className="text-body font-medium text-[#091A7A]">{request.plantName}</p>
                    </div>
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">SKU</p>
                      <p className="text-body font-medium text-[#091A7A]">{request.productSku}</p>
                    </div>
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">Batch</p>
                      <p className="text-body font-medium text-[#091A7A]">{request.batchNumber}</p>
                    </div>
                    <div className="bg-white/50 p-3 rounded-[var(--radius-small)]">
                      <p className="text-tiny text-[#9CA3AF]">Quantity</p>
                      <p className="text-body font-medium text-[#091A7A]">{request.quantity.toLocaleString()}</p>
                    </div>
                  </div>

                  <div className="bg-[#ADC8FF]/20 p-3 rounded-[var(--radius-small)]">
                    <p className="text-tiny text-[#091A7A]">
                      <strong>Method:</strong> {request.codeMethod}
                    </p>
                  </div>

                  {/* Generation Progress */}
                  {generatingId === request.id && (
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <p className="text-body">Generating QR codes...</p>
                        <p className="text-body font-medium text-[#091A7A]">{Math.round(progress)}%</p>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex lg:flex-col gap-2 min-w-[180px]">
                  {!request.generated && !generatingId && (
                    <motion.div whileTap={{ scale: 0.95 }} className="flex-1 lg:flex-none">
                      <Button
                        onClick={() => handleGenerate(request.id)}
                        className="w-full bg-[#091A7A] text-white rounded-[var(--radius-small)]"
                      >
                        <Play className="w-4 h-4 mr-2" />
                        Generate QR
                      </Button>
                    </motion.div>
                  )}

                  {request.generated && (
                    <>
                      <motion.div whileTap={{ scale: 0.95 }} className="flex-1 lg:flex-none">
                        <Button
                          onClick={() => handleDownloadCodes(request)}
                          variant="outline"
                          className="w-full border-[#091A7A] text-[#091A7A] rounded-[var(--radius-small)]"
                        >
                          <Download className="w-4 h-4 mr-2" />
                          Codes CSV
                        </Button>
                      </motion.div>
                      <motion.div whileTap={{ scale: 0.95 }} className="flex-1 lg:flex-none">
                        <Button
                          onClick={() => handleDownloadQRImages(request)}
                          variant="outline"
                          className="w-full border-[#091A7A] text-[#091A7A] rounded-[var(--radius-small)]"
                        >
                          <QrCode className="w-4 h-4 mr-2" />
                          QR Images
                        </Button>
                      </motion.div>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          ))}

          {requests.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-card-glass backdrop-blur-lg border border-white/20 rounded-[var(--radius-standard)] p-12 text-center"
            >
              <QrCode className="w-12 h-12 text-[#9CA3AF] mx-auto mb-4" />
              <h3 className="text-[#091A7A] mb-2">No Approved Requests</h3>
              <p className="text-body">There are no approved requests ready for QR code generation.</p>
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  );
}
