# QR Code Generation & Management System

## Overview
A comprehensive web-based prototype for managing QR code generation for product loyalty programs. This system handles the entire workflow from request creation through QR generation, printing, and historical tracking.

## Key Features

### 1. **User Role Management**
Four distinct user roles with specific permissions:
- **Inventory Admin**: Full system access
- **Inventory Manager**: Can manage requests, approve, and generate QR codes
- **Plant Staff**: Can create QR generation requests
- **Printer**: Can access print queue and manage printing operations

### 2. **Manufacturing Plant Management**
- Add, edit, and delete manufacturing plants
- Track plant details: location, capacity, manager
- Enable/disable plant status
- Search and filter plants

### 3. **Product Management**
- Comprehensive product catalog
- Product details: SKU, name, description, category, MRP
- Active/inactive product status
- Search functionality

### 4. **QR Generation Request System**
- Create requests with:
  - Manufacturing plant selection
  - Product selection
  - Batch number tracking
  - Quantity specification
  - Multiple code generation methods:
    - Alphanumeric serial numbers
    - Custom with prefix/suffix
    - Product info + MRP + unique code
    - Sequential serial numbers
- Add notes and special instructions

### 5. **Approval Workflow**
- View pending, approved, and rejected requests
- Approve/reject requests (Admin and Manager only)
- Real-time status updates
- Detailed request information display

### 6. **QR Code Generation**
- Generate QR codes for approved requests
- Progress tracking during generation
- Download options:
  - Coupon codes as CSV
  - QR code images
- Product-wise folder organization

### 7. **Print Queue Management**
- Self-adhesive A4 sheet printing support
- Multiple sheet formats:
  - A4 - 21 per sheet (3x7)
  - A4 - 24 per sheet (3x8)
  - A4 - 40 per sheet (5x8)
- Print/Reprint functionality
- Track printed vs. pending status
- Download print-ready files
- Printer connection status

### 8. **Generation History**
- Complete historical record
- Search by:
  - Request number
  - Product name
  - Batch number
  - Plant name
- Filter by print status:
  - Printed
  - Partially Printed
  - Not Printed
- Download historical data

### 9. **Dashboard & Analytics**
- Real-time statistics:
  - Total QR codes generated
  - Pending requests
  - Active plants and products
  - Print queue status
- Visual charts:
  - Plant-wise QR distribution (Bar chart)
  - Top products by QR codes (Pie chart)
- Recent activity timeline

## Technical Implementation

### Technologies Used
- **React**: Component-based UI
- **TypeScript**: Type-safe development
- **Tailwind CSS v4**: Modern styling
- **Framer Motion**: Smooth animations
- **Recharts**: Data visualization
- **Lucide React**: Icon library
- **LocalStorage**: Data persistence (mock backend)

### Code Generation Methods

1. **Alphanumeric Serial Number**
   - Random alphanumeric codes
   - Example: `ABC123XYZ789`

2. **Sequential Serial Number**
   - Incremental numbers
   - Example: `0000001`, `0000002`, `0000003`

3. **Custom with Prefix/Suffix**
   - Configurable prefix and suffix
   - Example: `PROD-UNIQUE-2026`

4. **Product Info + MRP + Unique Code**
   - Combines product details
   - Example: `TEA-500-P-450-UNIQUE123`

### QR Code Features

- **Unique Identification**: Every QR code is unique
- **Batch Tracking**: Linked to production batches
- **Plant Association**: Tracks manufacturing location
- **Product Mapping**: Connected to specific products
- **Print Status**: Monitors printing state
- **Download Options**: Multiple export formats

## Workflow

### 1. Setup Phase
- Admin adds manufacturing plants
- Admin adds products to catalog

### 2. Request Phase
- Plant Staff creates QR generation request
- Selects plant, product, batch, quantity
- Chooses code generation method
- Adds notes if needed

### 3. Approval Phase
- Manager/Admin reviews request
- Approves or rejects with feedback
- Request moves to generation queue

### 4. Generation Phase
- Manager/Admin generates QR codes
- System creates unique codes
- Codes converted to QR images
- Files organized in product folders

### 5. Printing Phase
- Print jobs added to queue
- Printer operator selects format
- Downloads print-ready files
- Prints to self-adhesive sheets
- Marks as printed in system

### 6. History & Tracking
- All operations logged
- Download capabilities maintained
- Reprint options available
- Historical analytics

## Print Format Specifications

### A4 Sheet Layouts
1. **21 per sheet (3x7)**: 63.5mm x 38.1mm per QR
2. **24 per sheet (3x8)**: 63.5mm x 33.9mm per QR
3. **40 per sheet (5x8)**: 48.5mm x 25.4mm per QR

### Print-Ready Features
- Proper spacing for cutting
- Self-adhesive compatible
- High-resolution QR codes
- Batch organization

## Data Structure

### QR Code Record
```typescript
{
  id: string;
  code: string;
  plantId: string;
  productId: string;
  batchNumber: string;
  generatedAt: timestamp;
  printStatus: 'not_printed' | 'printed';
  downloadCount: number;
}
```

## Future Enhancements (For Production)

### Backend Integration
- Database persistence (recommended: Supabase)
- Real API endpoints
- User authentication system
- File storage service

### Additional Features
- Actual QR code library integration (e.g., `qrcode.react`)
- Physical printer API integration
- Email notifications
- SMS alerts for scan events
- Customer-facing scan interface
- Loyalty points calculation
- Analytics dashboard expansion
- Export to PDF/Excel
- Barcode support
- Multi-language support

### Security Features
- Role-based access control (RBAC)
- Audit logging
- Data encryption
- Secure file downloads
- Rate limiting

## Demo Users

| Role | Email | Use Case |
|------|-------|----------|
| Admin User | admin@qrgen.com | Full system access |
| Manager User | manager@qrgen.com | Approve & generate |
| Plant Staff | staff@qrgen.com | Create requests |
| Printer Operator | printer@qrgen.com | Print operations |

## Getting Started

1. Select a user role on the login screen
2. Explore the dashboard
3. Navigate through different modules using the sidebar
4. Create plants and products (Admin/Manager)
5. Submit a QR generation request (Plant Staff)
6. Approve the request (Manager/Admin)
7. Generate QR codes
8. Add to print queue
9. Print QR codes
10. View history

## Notes

- This is a frontend prototype with mock data
- All data is stored in browser LocalStorage
- For production use, implement proper backend services
- QR images are simulated; integrate a real QR library
- Printer integration requires additional hardware APIs
- This system is designed for loyalty programs, not PII collection

## Support

For questions or customization requests, please refer to the documentation or contact the development team.

---

**Version**: 1.0.0  
**Last Updated**: February 8, 2026  
**License**: Proprietary
